<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Удаление аккаунта</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Удаление аккаунта</h1>
        <p>Вы уверены, что хотите удалить свой аккаунт? Все ваши произведения и комментарии останутся на платформе.</p>
        <form action="delete_account_handler.php" method="POST">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
            <input type="submit" name="delete" value="Удалить аккаунт">
        </form>
    </div>
</body>
</html>
