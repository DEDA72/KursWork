<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой профиль</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Мой профиль</h1>
        <p>Логин: <?php echo $username; ?></p>
        <p>E-mail: <?php echo $email; ?></p>
        <a href="change_profile.php">Изменить профиль</a>
    </div>
</body>
</html>