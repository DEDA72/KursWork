<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Изменить профиль</title>
</head>
<body>
    <div class="container">
        <h1>Изменить профиль</h1>
        <form action="#" method="POST">
            <input type="text" name="username" placeholder="Имя">
            <input type="email" name="email" placeholder="Email">
            <input type="password" name="password" placeholder="Пароль">
            <button type="submit" class="save-btn">Сохранить изменения</button>
        </form>
        <button class="delete-account-btn" onclick="confirmDelete()">Удалить аккаунт</button>
        <script>
            function confirmDelete() {
                if (confirm("Вы уверены, что хотите удалить свой аккаунт?")) {
                    window.location.href = "delete_account.php";
                }
            }
        </script>
    </div>
</body>
</html>
