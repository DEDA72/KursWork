<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Топ-50 произведений</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Топ-50 произведений</h1>
        <div class="sorting">
            <label for="sort">Сортировать по:</label>
            <select id="sort">
                <option value="genre">Жанру</option>
                <option value="rating">Оценкам</option>
                <option value="comments">Комментариям</option>
            </select>
        </div>
        <div class="works">
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function(){
        $('#sort').change(function(){
            var sortBy = $(this).val();
        });
    });
    </script>
</body>
</html>
