<?php include('header.php'); ?>
<?php
session_start();
include('header.php');
$pdo = new PDO('mysql:host=localhost;dbname=your_database_name', 'username', 'password');
if(isset($_GET['work_id'])) {
    $work_id = $_GET['work_id'];
    $stmt_work = $pdo->prepare("SELECT * FROM works WHERE id = :work_id");
    $stmt_work->execute(['work_id' => $work_id]);
    $work = $stmt_work->fetch(PDO::FETCH_ASSOC);

    if($work) {
        echo "<h2>{$work['title']}</h2>";
        echo "<p>Автор: {$work['author']}</p>";
        echo "<p>Жанр: {$work['genre']}</p>";
        echo "<p>Дата публикации: {$work['publication_date']}</p>";
        echo "<p>{$work['content']}</p>";
        
        echo "<h3>Оценить произведение:</h3>";
        echo "<form action='rate_work.php' method='post'>";
        echo "<input type='hidden' name='work_id' value='{$work_id}'>";
        echo "Рейтинг: <input type='number' name='rating' min='0' max='100' required>";
        echo "<input type='submit' value='Оценить'>";
        echo "</form>";
        $stmt_comments = $pdo->prepare("SELECT * FROM comments WHERE work_id = :work_id ORDER BY created_at DESC");
        $stmt_comments->execute(['work_id' => $work_id]);
        $comments = $stmt_comments->fetchAll(PDO::FETCH_ASSOC);

        if($comments) {
            echo "<h3>Комментарии:</h3>";
            echo "<ul>";
            foreach($comments as $comment) {
                echo "<li>{$comment['comment_text']}</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>Комментариев пока нет.</p>";
        }
        echo "<h3>Добавить комментарий:</h3>";
        echo "<form action='add_comment.php' method='post'>";
        echo "<input type='hidden' name='work_id' value='{$work_id}'>";
        echo "<textarea name='comment_text' rows='4' cols='50' required></textarea><br>";
        echo "<input type='submit' value='Добавить комментарий'>";
        echo "</form>";
    } else {
        echo "<p>Произведение не найдено.</p>";
    }
} else {
    echo "<p>Идентификатор произведения не указан.</p>";
}

include('footer.php');
?>
