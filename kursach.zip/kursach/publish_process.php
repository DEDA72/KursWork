<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION["username"])) {
        $servername = "localhost";
        $username = "username";
        $password = "password";
        $dbname = "database";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $title = $_POST["title"];
        $genre = $_POST["genre"];
        $content = $_POST["content"];
        $stmt = $conn->prepare("INSERT INTO works (title, genre, content, author) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $title, $genre, $content, $_SESSION["username"]);

        if ($stmt->execute()) {
            header("Location: publish_success.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }

        $conn->close();
    } else {
        header("Location: login.php");
        exit();
    }
}
?>
