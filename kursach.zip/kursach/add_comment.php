<?php
ession_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $comment = $_POST['comment'];
$sql = "INSERT INTO comments (user_id, work_id, comment_text) VALUES (:user_id, :work_id, :comment)";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->bindParam(':work_id', $work_id);
$stmt->bindParam(':comment', $comment);
$stmt->execute();
    echo "Комментарий успешно добавлен.";
} else {
    http_response_code(405);
    echo "Метод запроса не поддерживается.";
}
?>
