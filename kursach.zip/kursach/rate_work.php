<?php include('header.php'); ?>
 <?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rating = $_POST['rating'];

$sql = "INSERT INTO ratings (user_id, work_id, rating) VALUES (:user_id, :work_id, :rating)";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':user_id', $_SESSION['user_id']);
$stmt->bindParam(':work_id', $work_id);
$stmt->bindParam(':rating', $rating);
$stmt->execute();

    echo "Оценка успешно сохранена.";
} else {
    http_response_code(405);
    echo "Метод запроса не поддерживается.";
}
?>
