<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>писательская платформа</title>
</head>

<body>
    <nav>
        <ul>
        <li><a href="register.php">Регистрация</a></li>
            <li><a href="search_works.php">Поиск произведений</a></li>
            <li><a href="profile.php">Мой профиль</a></li>
            <li><a href="logout.php">Выйти</a></li>
            <li><a href="top_works.php">top3</a></li>
        </ul>
    </nav>
</body>
</html>
<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $title = $_POST['title'];
    $genre = $_POST['genre'];
    $content = $_POST['content'];
    
    $cover_image_name = $_FILES['cover_image']['name'];
    $cover_image_tmp_name = $_FILES['cover_image']['tmp_name'];
    $cover_image_path = 'uploads/' . $cover_image_name;
    
    move_uploaded_file($cover_image_tmp_name, $cover_image_path);
    
    $work_data = [
        'title' => $title,
        'genre' => $genre,
        'content' => $content,
        'cover_image' => $cover_image_path
    ];
    
    $works = json_decode(file_get_contents('works.json'), true);
    $works[] = $work_data;
    file_put_contents('works.json', json_encode($works));
    header('Location: publish_process.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Публикация произведения</title>
</head>
<body>
    <div class="container">
        <h2>Публикация произведения</h2>
        <form action="publish_process.php" method="post" enctype="multipart/form-data">
            <label for="title">Название произведения:</label>
            <input type="text" id="title" name="title" required><br>
            
            <label for="genre">Жанр:</label>
            <input type="text" id="genre" name="genre" required><br>
            
            <label for="content">Текст произведения:</label><br>
            <textarea id="content" name="content" rows="10" required></textarea><br>
            
            <label for="cover_image">Изображение обложки:</label>
            <input type="file" id="cover_image" name="cover_image"><br>
            
            <input type="submit" value="Опубликовать">
        </form>
    </div>
</body>
</html>
