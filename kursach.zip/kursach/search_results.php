<?php
$author = isset($_GET['author']) ? $_GET['author'] : '';
$title = isset($_GET['title']) ? $_GET['title'] : '';
$genre = isset($_GET['genre']) ? $_GET['genre'] : '';

$sql = "SELECT * FROM works WHERE 1";

if (!empty($author)) {
    $sql .= " AND author LIKE '%$author%'";
}

if (!empty($title)) {
    $sql .= " AND title LIKE '%$title%'";
}

if (!empty($genre)) {
    $sql .= " AND genre = '$genre'";
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Результаты поиска</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Результаты поиска</h1>
        <div class="search-results">
        </div>
    </div>
</body>
</html>
