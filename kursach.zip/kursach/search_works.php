<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Поиск произведений</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Поиск произведений</h1>
        <form action="search_results.php" method="GET">
            <label for="author">Автор:</label>
            <input type="text" id="author" name="author">

            <label for="title">Название:</label>
            <input type="text" id="title" name="title">

            <label for="genre">Жанр:</label>
            <select id="genre" name="genre">
                <option value="">Выберите жанр</option>
                <option value="фантастика">Фантастика</option>
                <option value="детектив">Детектив</option>
                <option value="триллер">Триллер</option>
                <option value="история">История</option>
            </select>

            <input type="submit" value="Искать">
        </form>
    </div>
</body>
</html>