<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <form action="register_process.php" method="POST">
            <h1>Регистрация</h1>
            <label for="username">Логин:</label>
            <input type="text" id="username" name="username" required><br>
            
            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required><br>
            
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required><br>
            
            <label for="confirm_password">Подтвердите пароль:</label>
            <input type="password" id="confirm_password" name="confirm_password" required><br>
            
            <input type="submit" value="Зарегистрироваться">
        </form>
    </div>
</body>
</html>